function h = h_whichItem(yt,t,in)
h = in.ind(:,t);