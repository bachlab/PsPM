function value = elvis(cond,a,b)
% ELVIS
% value = elvis(cond,a,b)
% if cond, then value = a, else value = b

if cond
    value = a;
else
    value = b;
end